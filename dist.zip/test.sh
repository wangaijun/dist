oldstr = './static'
newstr = 'static'
cat index.html | sed -n 's/$oldstr/$newstr/g'
